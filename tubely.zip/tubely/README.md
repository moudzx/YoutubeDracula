# Tubely — video/audio downloader with section trimming and playlist tools

A small local web app for downloading video in whatever format you choose (including
audio-only), with an optional start/end time so you only grab the part you need.

Backend: Flask + [yt-dlp](https://github.com/yt-dlp/yt-dlp) (does the actual downloading/muxing)
Trimming/audio-extraction: ffmpeg, invoked automatically by yt-dlp

## ⚠️ Please read before using

- yt-dlp is a legitimate, actively-maintained open-source tool — this app is just a UI around it.
- That said, downloading videos from YouTube (or any site) may violate that site's Terms of
  Service, and downloading copyrighted material without permission can be illegal depending on
  where you live and what you do with it.
- Use this only for content you own, have explicit permission to download, or that's licensed
  for reuse (Creative Commons, public domain, your own channel's uploads, etc.). This app does
  not check licensing for you.

## Requirements

- Python 3.9+
- **ffmpeg** installed and on your system PATH (required for merging video+audio, trimming
  sections, and MP3 conversion)
  - macOS: `brew install ffmpeg`
  - Ubuntu/Debian: `sudo apt install ffmpeg`
  - Windows: download from ffmpeg.org and add the `bin` folder to PATH

## Setup

```bash
cd tubely
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Run

```bash
python app.py
```

Then open **http://localhost:5000** in your browser.

## How it works

### Single video

1. Paste a video URL and click **Load**. The app fetches title, thumbnail, duration, and every
   available format.
2. Choose a mode: **Video** or **Audio only** — the quality dropdown filters to match.
3. For **Audio only**, check the box to convert straight to MP3 (192kbps).
4. Check **"Only download a section"** to reveal a start/end trim range (drag the sliders or
   type exact `HH:MM:SS` times). Leave it unchecked to grab the full video. This works in either
   mode — you can trim a section as video or as audio-only.
5. Click **Download**. The server:
   - uses yt-dlp's `download_ranges` feature to fetch/cut only the requested section when one is
     set (faster than downloading the whole video and trimming afterward, on sites that support it)
   - merges video+audio streams with ffmpeg if needed
   - converts to MP3 if requested
6. The file streams to your browser, then is deleted from the server shortly after.

### Playlists

Paste a playlist URL and click **Load** — the app detects it's a playlist and shows the track
list plus three modes:

- **One combined file** — downloads every track as audio and stitches them, in playlist order,
  into a single file. Pick the output format: MP3, M4A/AAC, Opus, or WAV.
- **Separate files — audio** — downloads each track as its own audio file (same format choices),
  delivered zipped up.
- **Separate files — video** — downloads each track as its own video file at your chosen quality
  cap (best available, 1080p, 720p, or 480p), delivered zipped up.

Notes on playlist mode:
- Unavailable tracks (private, deleted, region-locked) are skipped rather than failing the whole
  job.
- There's no section-trimming for playlists — it's always full tracks. Use the single-video flow
  if you want a trimmed clip.
- Very long playlists take a while, since every track downloads (and converts, for audio modes)
  individually before the final stitch or zip step.

## Fixing "Sign in to confirm you're not a bot"

YouTube sometimes challenges requests that don't look like they're coming from a logged-in
browser — this is a YouTube-side check, not a bug in the app. yt-dlp works around it by reusing
cookies from a real browser session. Pick **one** of these:

**Option A — use cookies straight from an installed browser (easiest):**

Set an environment variable before starting the app, naming a browser you're logged into
YouTube with:

```bash
export YTDLP_COOKIES_FROM_BROWSER=chrome   # or: firefox, edge, brave, safari, opera, vivaldi
python app.py
```

**Option B — export a cookies.txt file:**

1. Install a browser extension like "Get cookies.txt LOCALLY" (Chrome/Firefox) while logged into
   YouTube.
2. Export youtube.com cookies to a file, e.g. `cookies.txt`.
3. Point the app at it:
   ```bash
   export YTDLP_COOKIES_FILE=/full/path/to/cookies.txt
   python app.py
   ```

Notes:
- Option A is simpler but requires the browser to be closed on some OSes while yt-dlp reads its
  cookie store (Chrome in particular locks the file while running).
- These cookies are only sent to YouTube by yt-dlp itself, the same as they would be if you
  visited the site normally in that browser.
- If it still fails, also try upgrading yt-dlp (`pip install -U yt-dlp`) — YouTube changes its
  checks periodically and yt-dlp ships fixes frequently.



- This is built for local/personal use — there's no auth, rate limiting, or multi-user job
  queueing, so don't expose it directly to the public internet as-is.
- Some very high-res formats (e.g. 4K) are split video-only/audio-only streams by YouTube; the
  app automatically merges the best audio track with your chosen video stream via ffmpeg.
- If a download fails, the error message from yt-dlp is shown directly — often it's an
  age-restricted, private, or region-locked video, or the site changed something upstream
  (yt-dlp is updated frequently for this reason — `pip install -U yt-dlp` if things stop working).
- Playlists: pasting a playlist URL surfaces the three modes described above (combined file,
  separate audio, separate video) instead of only using the first video.
